export const EDU_CAREERS = [
  { id: "eng", name: "Engineering" },
  { id: "med", name: "Medical & Health Sciences" },
  { id: "bsc", name: "Bachelor of Science (B.Sc.)" }
];